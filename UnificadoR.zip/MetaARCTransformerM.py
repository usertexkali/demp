import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from collections import deque
from torch.utils.checkpoint import checkpoint
from typing import Dict, List, Optional, Tuple

class MetaModule(nn.Module):
    """Clase base para componentes con meta-learning"""
    def __init__(self):
        super().__init__()
        self.task_context = None
    
    def set_task_context(self, context: Dict):
        self.task_context = context
    
    def clone_params(self):
        """Clona parámetros para actualización rápida en meta-learning"""
        return {n: p.clone() for n, p in self.named_parameters()}
    
    def load_fast_params(self, fast_params: Dict):
        """Carga parámetros adaptados rápidamente"""
        for name, param in self.named_parameters():
            if name in fast_params:
                param.data = fast_params[name].data

class EnhancedMetaARCTransformer(nn.Module):
    """Transformer ARC mejorado con meta-learning y optimización de memoria"""
    
    def __init__(self, token_dim: int, model_dim: int, nhead: int, nhid: int, 
                 nlayers: int, num_strategies: int = 8, num_clusters: int = 8,
                 img_size: int = 30, patch_size: int = 5, meta_learn: bool = True,
                 use_checkpointing: bool = True):
        super().__init__()
        self.meta_learn = meta_learn
        self.use_checkpointing = use_checkpointing
        
        # =====================================================================
        # 1. Componentes de Procesamiento de Entrada
        # =====================================================================
        self.patch_embedding = nn.Conv2d(1, model_dim, patch_size, patch_size)
        self.pos_encoder_2d = PositionalEncoding2D(model_dim, img_size//patch_size, img_size//patch_size)
        
        # =====================================================================
        # 2. Sistema Meta-Cognitivo con Meta-Learning
        # =====================================================================
        self.strategy_reasoner = MetaStrategyReasoner(model_dim, num_strategies)
        self.adapters = nn.ModuleList([MetaResidualAdapter(model_dim) for _ in range(nlayers)])
        self.solution_monitor = MetaSolutionMonitor(model_dim)
        self.control_net = nn.GRUCell(model_dim, model_dim)
        self.context_memory = deque(maxlen=5)
        
        # =====================================================================
        # 3. Núcleo de Transformación con Gradient Checkpointing
        # =====================================================================
        encoder_layer = TransformerEncoderLayer(model_dim, nhead, nhid, batch_first=True, dropout=0.1)
        self.transformer = TransformerEncoder(encoder_layer, nlayers)
        
        # =====================================================================
        # 4. Componentes de Salida
        # =====================================================================
        self.pixel_head = nn.Linear(model_dim, 11)
        self.geometric_head = GeometricClustering(model_dim, num_clusters)
        
        # =====================================================================
        # 5. Parámetros Adaptativos
        # =====================================================================
        self.correction_factors = nn.Parameter(torch.tensor([0.3, 0.2]), requires_grad=True)
        self.confidence_threshold = nn.Parameter(torch.tensor(0.85), requires_grad=True)
        self.max_steps = 5

    def forward(self, tokens: torch.Tensor, task_context: Dict = None) -> Dict:
        # Configurar contexto para meta-learning
        if self.meta_learn and task_context:
            for module in [self.strategy_reasoner, self.solution_monitor, *self.adapters]:
                module.set_task_context(task_context)
        
        # Procesamiento inicial (con checkpointing si es necesario)
        if self.use_checkpointing:
            x = checkpoint(self._process_input, tokens)
        else:
            x = self._process_input(tokens)
        
        # Razonamiento estratégico con meta-learning
        strategy_vector, strategy_meta = self.strategy_reasoner(x, self.context_memory)
        self.update_context_memory(strategy_meta['context'])
        
        # Ejecución adaptativa con meta-learning
        outputs = self._adaptive_execution(x, strategy_vector, self.max_steps)
        
        # Generar salidas finales
        return self._generate_outputs(outputs['final_output'], outputs)

    def _process_input(self, tokens: torch.Tensor) -> torch.Tensor:
        """Procesamiento inicial con división en parches"""
        x = self.patch_embedding(tokens)
        x = x.permute(0, 2, 3, 1).flatten(1, 2)
        return self.pos_encoder_2d(x)

    def _adaptive_execution(self, x: torch.Tensor, strategy_vector: torch.Tensor, max_steps: int) -> Dict:
        """Bucle de ejecución adaptativa con meta-learning"""
        state = x.mean(dim=1)
        trajectory = []
        meta_info = {
            'confidence': torch.zeros(x.size(0)), 
            'correction_applied': torch.zeros(x.size(0)), 
            'adaptation_steps': []
        }

        for step in range(max_steps):
            # Transformación principal con checkpointing
            if self.use_checkpointing:
                x = checkpoint(self._transformer_step, x)
            else:
                x = self._transformer_step(x)
            
            # Aplicar adaptadores con meta-learning
            x, adapter_meta = self._apply_adapters(x, strategy_vector)
            meta_info['adaptation_steps'].append(adapter_meta)
            
            # Autoevaluación con meta-learning
            assessment, monitor_meta = self.solution_monitor(x, strategy_vector)
            meta_info['confidence'] = assessment['confidence']
            
            # Aplicar correcciones si es necesario
            if assessment['needs_correction'].any():
                x = self._apply_corrections(x, assessment)
                meta_info['correction_applied'] = assessment['needs_correction'].float()
            
            # Actualizar estado de control
            state = self.control_net(x.mean(dim=1), state)
            trajectory.append(x)
            
            # Terminación temprana por confianza
            if (assessment['confidence'] > self.confidence_threshold).all():
                break
        
        return {
            'final_output': trajectory[-1],
            'trajectory': trajectory,
            'steps': len(trajectory),
            'meta_info': meta_info
        }

    def _transformer_step(self, x: torch.Tensor) -> torch.Tensor:
        """Paso de transformación con posible gradient checkpointing"""
        return self.transformer(x)

    def _apply_adapters(self, x: torch.Tensor, strategy_vector: torch.Tensor) -> Tuple:
        """Aplica adaptadores con registro de meta-información"""
        adapter_meta = []
        for i, adapter in enumerate(self.adapters):
            # Clonar parámetros rápidos para meta-learning
            fast_params = adapter.clone_params() if self.meta_learn else None
            
            # Aplicar adaptador
            x = adapter(x, strategy_vector, fast_params)
            
            # Registrar meta-información
            if self.meta_learn:
                adapter_meta.append({
                    'adapter_id': i,
                    'fast_params': fast_params,
                    'output_norm': x.norm().item()
                })
        return x, adapter_meta

    def _apply_corrections(self, x: torch.Tensor, assessment: Dict) -> torch.Tensor:
        """Aplica correcciones basadas en autoevaluación"""
        correction_mask = assessment['needs_correction'].unsqueeze(1).unsqueeze(2)
        
        # Corrección de coherencia
        if assessment['assessment'][:, 0].min() < 0.6:
            global_feat = x.mean(dim=1, keepdim=True)
            x = torch.where(correction_mask, x + self.correction_factors[0] * global_feat, x)
        
        # Corrección de completitud
        if assessment['assessment'][:, 1].min() < 0.6:
            sparse_feat = self._compute_sparse_features(x)
            x = torch.where(correction_mask, x + self.correction_factors[1] * sparse_feat, x)
        
        return x

    def _compute_sparse_features(self, x: torch.Tensor) -> torch.Tensor:
        """Calcula características para corrección de completitud"""
        quantile_val = x.quantile(0.3, dim=1, keepdim=True)
        return x * (x < quantile_val).float()

    def _generate_outputs(self, x: torch.Tensor, outputs: Dict) -> Dict:
        """Genera las salidas finales del modelo"""
        pixel_logits = self.pixel_head(x)
        pixel_logits = self._reconstruct_2d(pixel_logits)
        cluster_assign = self.geometric_head(x)
        
        return {
            'pixel_logits': pixel_logits,
            'cluster_assign': cluster_assign,
            'trajectory': outputs['trajectory'],
            'steps': outputs['steps'],
            'meta_info': outputs['meta_info']
        }

    def _reconstruct_2d(self, x: torch.Tensor) -> torch.Tensor:
        """Reconstruye la salida a formato 2D"""
        B, seq_len, C = x.shape
        grid_size = int(math.sqrt(seq_len))
        x = x.view(B, grid_size, grid_size, C).permute(0, 3, 1, 2)
        return F.interpolate(x, size=(self.img_size, self.img_size), mode='nearest')

    def update_context_memory(self, context: torch.Tensor):
        """Actualiza la memoria contextual"""
        self.context_memory.append(context.detach().clone())
    
    def reset_context_memory(self):
        """Reinicia la memoria contextual"""
        self.context_memory.clear()

    def get_meta_params(self) -> Dict:
        """Obtiene parámetros para meta-learning"""
        return {
            'correction_factors': self.correction_factors,
            'confidence_threshold': self.confidence_threshold,
            'strategy_embeddings': self.strategy_reasoner.strategy_embeddings
        }

# =====================================================================
# Componentes Meta-Cognitivos con Meta-Learning
# =====================================================================
class MetaStrategyReasoner(MetaModule):
    """Sistema de toma de decisiones con meta-learning"""
    def __init__(self, model_dim: int, num_strategies: int = 8):
        super().__init__()
        self.utility_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, num_strategies)
        )
        self.strategy_embeddings = nn.Parameter(torch.randn(num_strategies, model_dim))
        
    def forward(self, x: torch.Tensor, history: deque) -> Tuple:
        context = x.mean(dim=1)
        hist_context = torch.stack(list(history)[-3:]).mean(dim=0) if history else torch.zeros_like(context)
        
        # Combinar contexto para decisión
        decision_input = torch.cat([context, context, hist_context], dim=-1)
        
        # Meta-learning: Usar parámetros rápidos si están disponibles
        if self.task_context and 'fast_params' in self.task_context:
            fast_params = self.task_context['fast_params']
            utility = F.linear(decision_input, fast_params['utility_predictor.0.weight'], 
                               fast_params['utility_predictor.0.bias'])
            utility = F.relu(utility)
            utility = F.linear(utility, fast_params['utility_predictor.2.weight'], 
                               fast_params['utility_predictor.2.bias'])
        else:
            utility = self.utility_predictor(decision_input)
        
        # Selección de estrategia con exploración
        strategy_probs = F.softmax(utility + 0.3 * torch.randn_like(utility), dim=-1)
        strategy_idx = torch.multinomial(strategy_probs, 1)
        strategy_vector = self.strategy_embeddings[strategy_idx].squeeze(1)
        
        return strategy_vector, {
            'strategy_probs': strategy_probs,
            'context': context,
            'decision_input': decision_input
        }

class MetaResidualAdapter(MetaModule):
    """Adaptador paramétrico con meta-learning"""
    def __init__(self, dim: int, bottleneck: int = 32, alpha: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, bottleneck),
            nn.ReLU(),
            nn.Linear(bottleneck, dim)
        )
        self.strategy_proj = nn.Linear(dim, bottleneck)
        self.alpha = alpha

    def forward(self, x: torch.Tensor, strategy_vector: torch.Tensor, 
                fast_params: Optional[Dict] = None) -> torch.Tensor:
        # Usar parámetros rápidos para meta-learning
        if fast_params:
            out = F.linear(x, fast_params['net.0.weight'], fast_params['net.0.bias'])
            out = F.relu(out)
            out = F.linear(out, fast_params['net.2.weight'], fast_params['net.2.bias'])
        else:
            out = self.net(x)
        
        # Inyección estratégica
        if strategy_vector is not None:
            strategy_feat = self.strategy_proj(strategy_vector).unsqueeze(1)
            out = out + strategy_feat
        
        return x + self.alpha * out

class MetaSolutionMonitor(MetaModule):
    """Sistema de autoevaluación con meta-learning"""
    def __init__(self, model_dim: int):
        super().__init__()
        self.quality_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, 4)  # Coherencia, completitud, precisión, eficiencia
        )
        
    def forward(self, solution: torch.Tensor, strategy_vector: torch.Tensor) -> Dict:
        solution_context = solution.mean(dim=1)
        input_context = solution_context  # Usar contexto actual como entrada proxy
        
        # Meta-learning: Usar parámetros rápidos si están disponibles
        if self.task_context and 'fast_params' in self.task_context:
            fast_params = self.task_context['fast_params']
            assessment = F.linear(
                torch.cat([solution_context, input_context, strategy_vector], dim=-1),
                fast_params['quality_predictor.0.weight'],
                fast_params['quality_predictor.0.bias']
            )
            assessment = F.relu(assessment)
            assessment = F.linear(
                assessment,
                fast_params['quality_predictor.2.weight'],
                fast_params['quality_predictor.2.bias']
            )
        else:
            assessment = self.quality_predictor(
                torch.cat([solution_context, input_context, strategy_vector], dim=-1)
            )
        
        # Calcular confianza
        probs = F.softmax(assessment, dim=-1)
        entropy = -(probs * torch.log(probs + 1e-9)).sum(dim=-1)
        confidence = 1.0 - entropy / torch.log(torch.tensor(4.0))
        
        return {
            'assessment': assessment,
            'confidence': confidence,
            'needs_correction': torch.any(probs < 0.6, dim=-1),
            'probs': probs
        }

class GeometricClustering(nn.Module):
    """Agrupamiento geométrico con atención especializada"""
    def __init__(self, token_dim: int, num_clusters: int = 8):
        super().__init__()
        self.centers = nn.Parameter(torch.randn(num_clusters, token_dim) * 0.1)
        self.spatial_attn = nn.MultiheadAttention(token_dim, 4, batch_first=True)
        
    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        attn_out, _ = self.spatial_attn(tokens, tokens, tokens)
        dists = torch.cdist(attn_out, self.centers.unsqueeze(0).expand(tokens.size(0), -1, -1))
        return F.softmax(-dists, dim=-1)

class PositionalEncoding2D(nn.Module):
    """Codificación posicional 2D optimizada para memoria"""
    def __init__(self, d_model: int, height: int, width: int, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        # Generar PE de forma eficiente
        pe_h = self._generate_pe(height, d_model)
        pe_w = self._generate_pe(width, d_model)
        
        self.register_buffer('pe_h', pe_h.unsqueeze(1))
        self.register_buffer('pe_w', pe_w.unsqueeze(0))
        
    def _generate_pe(self, length: int, d_model: int) -> torch.Tensor:
        position = torch.arange(0, length).float().unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe = torch.zeros(length, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.pe_h + self.pe_w
        return self.dropout(x)