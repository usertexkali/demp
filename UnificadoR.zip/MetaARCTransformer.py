import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from collections import deque
from copy import deepcopy
from typing import Dict, List, Optional, Tuple

class MetaARCTransformer(nn.Module):
    """Transformer ARC mejorado con capacidades meta-cognitivas avanzadas"""
    
    def __init__(self, token_dim: int, model_dim: int, nhead: int, nhid: int, 
                 nlayers: int, num_strategies: int = 8, num_clusters: int = 8,
                 img_size: int = 30, patch_size: int = 5, debug: bool = False):
        super().__init__()
        self.debug = debug
        self.token_dim = token_dim
        self.model_dim = model_dim
        self.img_size = img_size
        self.patch_size = patch_size
        self.grid_size = img_size // patch_size
        
        # =====================================================================
        # 1. Componentes de Procesamiento de Entrada
        # =====================================================================
        # Procesamiento por parches para imágenes 2D
        self.patch_embedding = nn.Conv2d(1, model_dim, kernel_size=patch_size, stride=patch_size)
        self.pos_encoder_2d = PositionalEncoding2D(model_dim, self.grid_size, self.grid_size)
        
        if debug:
            print(f"[Init] Patch Embedding: kernel={patch_size}, stride={patch_size}")
            print(f"[Init] Grid Size: {self.grid_size}x{self.grid_size}")
            print(f"[Init] Positional Encoding 2D: dim={model_dim}, h={self.grid_size}, w={self.grid_size}")

        # =====================================================================
        # 2. Sistema Meta-Cognitivo Avanzado
        # =====================================================================
        # Razonamiento estratégico con exploración controlada
        self.strategy_reasoner = StrategyReasoner(model_dim, num_strategies)
        
        # Adaptadores residuales por capa con inyección estratégica
        self.adapters = nn.ModuleList([
            ResidualAdapter(model_dim) for _ in range(nlayers)
        ])
        
        # Sistema de autoevaluación crítica
        self.solution_monitor = SolutionMonitor(model_dim)
        
        # Control de ejecución adaptativa
        self.control_net = nn.GRUCell(model_dim, model_dim)
        
        # Memoria contextual (historial de estrategias)
        self.context_memory = deque(maxlen=5)
        
        # =====================================================================
        # 3. Núcleo de Transformación
        # =====================================================================
        encoder_layer = TransformerEncoderLayer(
            d_model=model_dim, 
            nhead=nhead, 
            dim_feedforward=nhid,
            batch_first=True,
            dropout=0.1
        )
        self.transformer = TransformerEncoder(encoder_layer, num_layers=nlayers)
        
        # =====================================================================
        # 4. Componentes de Salida Mejorados
        # =====================================================================
        self.pixel_head = nn.Linear(model_dim, 11)  # 11 clases (0-10)
        self.geometric_head = GeometricClustering(model_dim, num_clusters)
        
        # =====================================================================
        # 5. Parámetros Operativos
        # =====================================================================
        self.max_steps = 5  # Máximo de pasos de razonamiento
        self.confidence_threshold = 0.85  # Umbral para terminación temprana
        self.correction_factors = nn.Parameter(torch.tensor([0.3, 0.2]), requires_grad=True)

    def forward(self, tokens: torch.Tensor, max_steps: Optional[int] = None) -> Dict:
        """
        Procesamiento completo con capacidades meta-cognitivas
        
        Args:
            tokens: Tensor de entrada [B, C, H, W]
            max_steps: Máximo de pasos de razonamiento (opcional)
            
        Returns:
            Dict con resultados y metadatos del proceso
        """
        B = tokens.size(0)
        max_steps = max_steps or self.max_steps
        
        if self.debug:
            print(f"\n{'='*50}")
            print(f"STARTING FORWARD PASS")
            print(f"Input shape: {tokens.shape}")
            print(f"Batch size: {B}, Max steps: {max_steps}")
            print(f"{'='*50}\n")

        # =====================================================================
        # FASE 1: PROCESAMIENTO INICIAL (2D PATCH PROCESSING)
        # =====================================================================
        # Convertir a representación 2D por parches
        # Convertir imagen a parches 2D
        x = self.patch_embedding(tokens)  # [B, 1, 30, 30] -> [B, 128, 6, 6]
        # x = self.patch_embedding(tokens)  # [B, D, grid_h, grid_w]
        if self.debug:
            print(f"[Patch Embedding] Input: {tokens.shape} -> Output: {x.shape}")
        
        # Reestructurar y aplicar codificación posicional
        x = x.permute(0, 2, 3, 1)  # [B, grid_h, grid_w, D]
        x = x.reshape(B, -1, self.model_dim)  # [B, seq_len, D] -> [B, 36, 128]
        x = self.pos_encoder_2d(x)  # Aplicar codificación posicional 2D
        
        if self.debug:
            print(f"[Positional Encoding] Output: {x.shape}")

        # Representación inicial del problema -> Salida: Tensores con información espacial preservada y contexto global.
        initial_context = x.mean(dim=1)  # [B, D] 
        
        if self.debug:
            print(f"[Context Extraction] Initial context shape: {initial_context.shape}")

        # =====================================================================
        # FASE 2: RAZONAMIENTO ESTRATÉGICO CON EXPLORACIÓN
        # =====================================================================
        strategy_vector = self.strategy_reasoner(
            initial_context, 
            initial_context, 
            self.context_memory
        )
         
        if self.debug:
            print(f"[Strategy Reasoning] Strategy vector shape: {strategy_vector.shape}")
            print(f"Strategy vector norms: {torch.norm(strategy_vector, dim=1).detach().cpu().numpy()}")

        # Actualizar memoria contextual
        self.update_context_memory(initial_context) ### Salida: Vector de estrategia que guía el procesamiento adaptativo.
        
        if self.debug:
            print(f"[Context Memory] Updated memory size: {len(self.context_memory)}")

        # =====================================================================
        # FASE 3: EJECUCIÓN ADAPTATIVA (MULTI-STEP REASONING)
        # =====================================================================
        state = initial_context.clone()
        solution_trajectory = []
        confidence = torch.zeros(B, device=tokens.device)
        needs_correction = torch.ones(B, dtype=torch.bool, device=tokens.device)
        correction_applied = torch.zeros(B, dtype=torch.bool, device=tokens.device)
        
        for step in range(max_steps):
            if self.debug:
                print(f"\n{'='*30}")
                print(f"REASONING STEP {step+1}/{max_steps}")
                print(f"Input shape to transformer: {x.shape}")
                print(f"State shape: {state.shape}")
                print(f"{'='*30}")

            # Transformación principal
            x = self.transformer(x)
            
            if self.debug:
                print(f"[Transformer] Output shape: {x.shape}")

            # Aplicar adaptadores condicionados por estrategia
            for i, adapter in enumerate(self.adapters):
                x = adapter(x, prior=strategy_vector)
                if self.debug and step == 0:
                    print(f"[Adapter {i}] Applied with strategy conditioning")

            # =================================================================
            # FASE 4: AUTOVALUACIÓN CRÍTICA
            # =================================================================
            assessment = self.solution_monitor(x, tokens, strategy_vector)
            confidence = assessment['confidence']
            needs_correction = assessment['needs_correction']
            
            if self.debug:
                print(f"[Solution Monitor] Confidence: {confidence.mean().item():.4f}")
                print(f"Needs correction: {needs_correction.sum().item()}/{B} samples")
                print(f"Assessment scores: {assessment['assessment'][0].detach().cpu().numpy()}")

            # =================================================================
            # FASE 5: ADAPTACIÓN EN TIEMPO REAL
            # =================================================================
            if needs_correction.any(): # --> Corrección en Tiempo Real:
                correction_applied[needs_correction] = True
                correction_mask = needs_correction.unsqueeze(1).unsqueeze(2)
                
                # Corrección de coherencia
                if assessment['assessment'][:, 0].min() < 0.6:
                    global_feat = x.mean(dim=1, keepdim=True)
                    correction = self.correction_factors[0] * global_feat
                    x = torch.where(correction_mask, x + correction, x)
                    if self.debug:
                        print(f"[Coherence Correction] Applied to {needs_correction.sum().item()} samples")
                        print(f"Correction factor: {self.correction_factors[0].item():.4f}")

                # Corrección de completitud
                if assessment['assessment'][:, 1].min() < 0.6:
                    sparse_feat = self.compute_sparse_features(x)
                    correction = self.correction_factors[1] * sparse_feat
                    x = torch.where(correction_mask, x + correction, x)
                    if self.debug:
                        print(f"[Completeness Correction] Applied to {needs_correction.sum().item()} samples")
                        print(f"Correction factor: {self.correction_factors[1].item():.4f}")
            
            # Actualizar estado de control
            state = self.control_net(x.mean(dim=1), state)
            solution_trajectory.append(x.clone())
            
            if self.debug:
                print(f"[Control Network] Updated state shape: {state.shape}")
                print(f"Trajectory length: {len(solution_trajectory)}")

            # Terminación temprana si alta confianza
            if (confidence > self.confidence_threshold).all():
                if self.debug:
                    print(f"🟢 EARLY TERMINATION at step {step+1} - Confidence threshold reached")
                break
        
        # =====================================================================
        # FASE 6: GENERACIÓN DE SALIDA
        # =====================================================================
        # Usar el último estado de la trayectoria
        final_output = solution_trajectory[-1]
        
        # Cabezas de salida
        pixel_logits = self.pixel_head(final_output)
        cluster_assign = self.geometric_head(final_output)
        
        # Reconstruir a formato 2D
        pixel_logits = self.reconstruct_2d(pixel_logits)
        
        if self.debug:
            print(f"\n{'='*50}")
            print(f"OUTPUT GENERATION")
            print(f"Pixel logits shape: {pixel_logits.shape}")
            print(f"Cluster assignment shape: {cluster_assign.shape}")
            print(f"Total steps used: {len(solution_trajectory)}")
            print(f"Final confidence: {confidence.mean().item():.4f}")
            print(f"Correction applied to: {correction_applied.sum().item()}/{B} samples")
            print(f"{'='*50}")

        return {
            'pixel_logits': pixel_logits,
            'cluster_assign': cluster_assign,
            'strategy_vector': strategy_vector,
            'trajectory': solution_trajectory,
            'steps': len(solution_trajectory),
            'confidence': confidence,
            'needed_correction': needs_correction,
            'correction_applied': correction_applied
        }
    
    def compute_sparse_features(self, x: torch.Tensor) -> torch.Tensor:
        """Calcula características para corrección de completitud"""
        # Atención a componentes infra-representados
        quantile_val = x.quantile(0.3, dim=1, keepdim=True)
        sparse_mask = (x < quantile_val).float()
        return x * sparse_mask
    
    def reconstruct_2d(self, x: torch.Tensor) -> torch.Tensor:
        """Reconstruye la salida a formato 2D"""
        B, seq_len, C = x.shape
        x = x.view(B, self.grid_size, self.grid_size, C)
        x = x.permute(0, 3, 1, 2)  # [B, C, grid_h, grid_w]
        x = F.interpolate(x, size=(self.img_size, self.img_size), mode='nearest')
        return x
    
    def update_context_memory(self, context: torch.Tensor):
        """Actualiza la memoria contextual con contexto nuevo"""
        self.context_memory.append(context.detach().clone())
    
    def reset_context_memory(self):
        """Reinicia la memoria contextual entre tareas"""
        self.context_memory.clear()

# =============================================================================
# Componentes Meta-Cognitivos (Implementación Completa)
# =============================================================================
class PositionalEncoding2D(nn.Module):
    """Codificación posicional 2D para preservar información espacial en imágenes"""
    def __init__(self, d_model: int, height: int, width: int, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        # Codificación para dimensiones de altura
        pe_h = torch.zeros(height, d_model)
        position_h = torch.arange(0, height, dtype=torch.float).unsqueeze(1)
        div_term_h = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe_h[:, 0::2] = torch.sin(position_h * div_term_h)
        pe_h[:, 1::2] = torch.cos(position_h * div_term_h)
        
        # Codificación para dimensiones de ancho
        pe_w = torch.zeros(width, d_model)
        position_w = torch.arange(0, width, dtype=torch.float).unsqueeze(1)
        div_term_w = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe_w[:, 0::2] = torch.sin(position_w * div_term_w)
        pe_w[:, 1::2] = torch.cos(position_w * div_term_w)
        
        self.register_buffer('pe_h', pe_h.unsqueeze(1).unsqueeze(0))  # [1, height, 1, d_model]
        self.register_buffer('pe_w', pe_w.unsqueeze(0).unsqueeze(0))  # [1, 1, width, d_model]
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Aplica codificación posicional 2D"""
        x = x + self.pe_h + self.pe_w
        return self.dropout(x)

class StrategyReasoner(nn.Module):
    """Sistema de toma de decisiones estratégicas con exploración controlada"""
    def __init__(self, model_dim: int, num_strategies: int = 8, context_size: int = 3):
        super().__init__()
        self.utility_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, num_strategies)
        )
        self.strategy_embeddings = nn.Parameter(torch.randn(num_strategies, model_dim))
        self.context_size = context_size
        
    def forward(self, context: torch.Tensor, problem_embed: torch.Tensor, 
                history: deque) -> torch.Tensor:
        """Selecciona estrategia basada en contexto e historial"""
        # Combinar contexto histórico
        if len(history) > 0:
            hist_context = torch.stack(list(history)[-self.context_size:]).mean(dim=0)
        else:
            hist_context = torch.zeros_like(context)

        ### Fase 2: Razonamiento Estratégico
        # Entrada: [contexto actual, problema, contexto histórico]
        # Combinar contexto actual, histórico y del problema
        # decision_input = cat([context, problem_embed, hist_context])  # [B, 384]
        decision_input = torch.cat([context, problem_embed, hist_context], dim=-1)
        # Predecir utilidad de estrategias
        utility = self.utility_predictor(decision_input)  # [B, 8]
        
        # Selección con exploración controlada (ruido gaussiano)
        strategy_probs = F.softmax(utility + 0.3 * torch.randn_like(utility), dim=-1)   # [B, 8]
        strategy_idx = torch.multinomial(strategy_probs, 1)  # [B, 1]
        strategy_vector = self.strategy_embeddings[strategy_idx].squeeze(1) # [B, 128]

        return strategy_vector # Salida: Vector de estrategia que guía el procesamiento adaptativo.

class SolutionMonitor(nn.Module):
    """Sistema de autoevaluación crítica de soluciones"""
    def __init__(self, model_dim: int):
        super().__init__()
        self.quality_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, 4)  # Coherencia, completitud, precisión, eficiencia
        )
        
    def forward(self, solution: torch.Tensor, input_tokens: torch.Tensor, 
                strategy_vector: torch.Tensor) -> Dict:
        """Evalúa la calidad de una solución"""
        # Preparar entradas (promedio sobre secuencia)
        solution_context = solution.mean(dim=1)  # [B, D]
        input_context = input_tokens.mean(dim=1)  # [B, D]
        
        # Evaluación multidimensional
        assessment = self.quality_predictor(
            torch.cat([solution_context, input_context, strategy_vector], dim=-1)
        )
        
        # Calcular confianza (inverso de la entropía)
        probs = F.softmax(assessment, dim=-1)
        entropy = -(probs * torch.log(probs + 1e-9)).sum(dim=-1)
        confidence = 1.0 - entropy / torch.log(torch.tensor(4.0))  # Normalizado
        
        return {
            'assessment': assessment,
            'confidence': confidence,
            'needs_correction': torch.any(probs < 0.6, dim=-1)
        }

class ResidualAdapter(nn.Module):
    """Módulo de adaptación paramétrica condicionado por estrategia"""
    def __init__(self, dim: int, bottleneck: int = 32, alpha: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, bottleneck),
            nn.ReLU(),
            nn.Linear(bottleneck, dim)
        )
        self.strategy_proj = nn.Linear(dim, bottleneck)
        self.alpha = alpha

    def forward(self, x: torch.Tensor, prior: Optional[torch.Tensor] = None) -> torch.Tensor:
        """Aplica adaptación paramétrica"""
        out = self.net(x)
        if prior is not None:
            # Proyectar estrategia y combinar
            strategy_feat = self.strategy_proj(prior).unsqueeze(1)
            out = out + strategy_feat
        return x + self.alpha * out

class GeometricClustering(nn.Module):
    """Módulo de agrupamiento geométrico para análisis espacial"""
    def __init__(self, token_dim: int, num_clusters: int = 8):
        super().__init__()
        self.centers = nn.Parameter(torch.randn(num_clusters, token_dim) * 0.1)
        self.spatial_attn = nn.MultiheadAttention(token_dim, num_heads=4, batch_first=True)
        
    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        """Calcula asignación suave a clusters"""
        attn_out, _ = self.spatial_attn(tokens, tokens, tokens)
        dists = torch.cdist(attn_out, self.centers.unsqueeze(0).expand(tokens.size(0), -1, -1))
        return F.softmax(-dists, dim=-1)