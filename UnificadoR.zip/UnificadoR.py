import random
import os
import torch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
import json
import math
from glob import glob
from torch import nn
from torch.nn import TransformerEncoderLayer, TransformerEncoder
from torch.utils.data import Dataset
from collections import deque
import torch.nn.functional as F
from copy import deepcopy
from typing import List, Tuple, Optional, Dict

# =============================================================================
# Configuración Global y Utilidades
# =============================================================================
# Configuración de colores para visualización
CMAP = colors.ListedColormap(
    ['#000000', '#0074D9', '#FF4136', '#2ECC40', '#FFDC00',
     '#AAAAAA', '#F012BE', '#FF851B', '#7FDBFF', '#870C25', '#FFFFFF'])
NORM = colors.Normalize(vmin=0, vmax=10)

def seed_everything(seed: int = 42):
    """Fija todas las semillas para garantizar reproducibilidad"""
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True

PAD_VALUE = 10  # Definición centralizada de valor de padding

def create_batchO(task_paths: List[str], out_rows: int, out_cols: int) -> Tuple:
    """
    Crea un batch de tareas a partir de archivos JSON
    
    Args:
        task_paths: Lista de rutas a archivos de tareas
        out_rows: Alto máximo de las imágenes
        out_cols: Ancho máximo de las imágenes
    
    Returns:
        Tupla con (x_train, y_train, x_val, y_val)
    """
    x_batch = []
    y_batch = []

    x_test_batch = []
    y_test_batch = []
    for task_file in task_paths:
        with open(task_file, 'r') as f:
            task = json.load(f)

        input_im1, output_im1, not_valid = pad_im(task, out_rows,
                                                  out_cols, mode='train')
        if not_valid:
            continue

        input_im, output_im, not_valid = pad_im(task, out_rows,
                                                out_cols, mode='test')
        if not_valid:
            continue

        x_batch.extend(input_im1[None])
        y_batch.extend(output_im1[None])
        x_test_batch.extend(input_im[None])
        y_test_batch.extend(output_im[None])
    return x_batch, y_batch, x_test_batch, y_test_batch

def create_batch(task_paths: List[str], out_rows: int, out_cols: int) -> Tuple:
    """Implementación completa necesaria aquí"""
    # Ejemplo básico de implementación (reemplazar con lógica real)
    train_x, train_y = [], []
    val_x, val_y = [], []
    
    for path in task_paths:
        with open(path) as f:
            task = json.load(f)
            # Procesar ejemplos de entrenamiento
            for example in task['train']:
                x, y, _ = pad_im(example, out_rows, out_cols, 'train')
                train_x.append(x)
                train_y.append(y)
            # Procesar ejemplos de prueba
            for example in task['test']:
                x, y, _ = pad_im(example, out_rows, out_cols, 'test')
                val_x.append(x)
                val_y.append(y)
    
    return train_x, train_y, np.array(val_x), np.array(val_y)


def pad_imO(task: Dict, out_rows: int, out_cols: int, mode: str = 'train', cval: int = 10) -> Tuple:
    """
    Ajusta una imagen al tamaño especificado con padding
    
    Args:
        task: Diccionario con datos de la tarea
        out_rows: Alto deseado
        out_cols: Ancho deseado
        mode: 'train' o 'test'
        cval: Valor para padding
    
    Returns:
        Tupla con (imagen_entrada, imagen_salida, valid_flag)
    """
    ip = []
    op = []
    num_pairs = len(task[mode])
    input_im = np.zeros((num_pairs, 1, out_rows, out_cols))
    output_im = np.zeros(
        (num_pairs, 1, out_rows, out_cols), dtype=np.long)
    for task_num in range(num_pairs):
        im = np.array(task[mode][task_num]['input'])
        nrows, ncols = im.shape
        if (nrows > out_rows) or (ncols > out_cols):
            return 0, 0, 1
        im = np.pad(im, ((out_rows-nrows, 0), (out_cols-ncols, 0)), mode='constant',
                    constant_values=(cval, cval))

        input_im[task_num, 0] = im
        im = np.array(task[mode][task_num]['output'])
        nrows, ncols = im.shape
        if (nrows > out_rows) or (ncols > out_cols):
            return 0, 0, 1
        im = np.pad(im, ((out_rows-nrows, 0), (out_cols-ncols, 0)), mode='constant',
                    constant_values=(cval, cval))
        output_im[task_num, 0] = im
    ip.extend(input_im)
    op.extend(output_im)

    return np.vstack(ip), np.vstack(op), 0

def pad_im(task: Dict, out_rows: int, out_cols: int, mode: str = 'train', cval: int = PAD_VALUE) -> Tuple:
    """Implementación completa necesaria aquí"""
    # Ejemplo básico de implementación
    input_grid = np.array(task['input'])
    output_grid = np.array(task['output']) if mode == 'train' else None
    
    # Padding básico
    padded_input = np.pad(input_grid, 
                         ((0, out_rows - input_grid.shape[0]), 
                          (0, out_cols - input_grid.shape[1])),
                         'constant', constant_values=cval)
    
    if mode == 'train':
        padded_output = np.pad(output_grid,
                             ((0, out_rows - output_grid.shape[0]),
                              (0, out_cols - output_grid.shape[1])),
                             'constant', constant_values=cval)
        return padded_input, padded_output.flatten(), True
    else:
        return padded_input, np.zeros(out_rows*out_cols), True

# =============================================================================
# Configuración Global (MODIFICADO)
# =============================================================================
PAD_VALUE = 0  # Ahora usamos 0 para padding en binario
BINARY_THRESHOLD = 0.3  # Umbral para conversión a binario

def pad_imBW(task: Dict, out_rows: int, out_cols: int, mode: str = 'train', cval: int = PAD_VALUE) -> Tuple:
    """Ajusta imagen con conversión a binario"""
    # Ejemplo básico de implementación
    input_grid = np.array(task['input'])
    output_grid = np.array(task['output']) if mode == 'train' else None
    
    # Padding básico
    padded_input = np.pad(input_grid, 
                         ((0, out_rows - input_grid.shape[0]), 
                          (0, out_cols - input_grid.shape[1])),
                         'constant', constant_values=cval)
    
    # Convertir a binario después del padding
    input_grid = (input_grid > BINARY_THRESHOLD).astype(np.float32)
    if mode == 'train':
        output_grid = (output_grid > BINARY_THRESHOLD).astype(np.float32)
    
    return input_grid, output_grid.flatten(), True

def create_batchBW(task_paths: List[str], out_rows: int, out_cols: int) -> Tuple:
    """Crea batch con imágenes binarias"""
    """Implementación completa necesaria aquí"""
    # Ejemplo básico de implementación (reemplazar con lógica real)
    train_x, train_y = [], []
    val_x, val_y = [], []
    
    for path in task_paths:
        with open(path) as f:
            task = json.load(f)
            # Procesar ejemplos de entrenamiento
            for example in task['train']:
                x, y, _ = pad_im(example, out_rows, out_cols, 'train')
                train_x.append(x)
                train_y.append(y)
            # Procesar ejemplos de prueba
            for example in task['test']:
                x, y, _ = pad_im(example, out_rows, out_cols, 'test')
                val_x.append(x)
                val_y.append(y) 

    # Asegurar conversión a binario en todos los datos
    for i in range(len(train_x)):
        train_x[i] = (train_x[i] > BINARY_THRESHOLD).astype(np.float32)
        train_y[i] = (train_y[i] > BINARY_THRESHOLD).astype(np.float32)
    
    for i in range(len(val_x)):
        val_x[i] = (val_x[i] > BINARY_THRESHOLD).astype(np.float32)
        val_y[i] = (val_y[i] > BINARY_THRESHOLD).astype(np.float32)
    
    return train_x, train_y, np.array(val_x), np.array(val_y)

def plot_figure(x_spt: torch.Tensor, y_spt: torch.Tensor, x_qry: torch.Tensor,
                pred_q: torch.Tensor, im_num: int, img_sz: int = 30):
    """
    Visualiza comparación entre entrada, objetivo y predicción
    
    Args:
        x_spt: Tensor de entrada de entrenamiento
        y_spt: Tensor de salida esperada
        x_qry: Tensor de entrada de prueba
        pred_q: Tensor de predicción
        im_num: Número de imagen para guardar
        img_sz: Tamaño de la imagen
    """
    plt.figure()
    plt.subplot(2, 2, 1)
    plt.title("Input de entrenamiento")
    plt.imshow(x_spt[0].cpu().numpy().reshape(img_sz, img_sz),
               cmap=cmap, norm=norm)

    plt.subplot(2, 2, 2)
    plt.title("Salida esperada")
    plt.imshow(y_spt[:img_sz*img_sz].cpu().numpy().reshape(img_sz, img_sz),
               cmap=cmap, norm=norm)

    plt.subplot(2, 2, 3)
    plt.title("Input de prueba")
    plt.imshow(x_qry[0].cpu().numpy().reshape(img_sz, img_sz),
               cmap=cmap, norm=norm)

    # do visualization only for the first input.
    pred_q = pred_q[0, :img_sz*img_sz].cpu().numpy().reshape(img_sz, img_sz)
    frow = np.nonzero(np.count_nonzero(pred_q-10, axis=1))[0][0]
    fcol = np.nonzero(np.count_nonzero(pred_q-10, axis=0))[0][0]
    a = np.copy(pred_q[frow:, fcol:])
    a[a == 10] = 0

    plt.subplot(2, 2, 4)
    plt.title("Predicción")

    plt.imshow(a, cmap=cmap, norm=norm)

    plt.savefig(f'/content/drive/MyDrive/testMeta/model_preds/epoch_30_preds_{im_num}.png')
    plt.close()

# =============================================================================
# Clase Base para Persistencia (NUEVO)
# =============================================================================
class KnowledgePersistentModule(nn.Module):
    """Clase base para módulos con persistencia de conocimiento"""
    def __init__(self):
        super().__init__()
        self.knowledge_path = None
    
    def save_knowledge(self, path: str):
        """Guarda el conocimiento del modelo"""
        self.knowledge_path = path
        torch.save({
            'state_dict': self.state_dict(),
            'config': self._get_config()
        }, path)
        print(f"Knowledge saved to {path}")
    
    def load_knowledge(self, path: str, device: torch.device):
        """Carga conocimiento existente"""
        if not os.path.exists(path):
            print(f"Knowledge not found at {path}. Initializing from scratch.")
            return
        
        checkpoint = torch.load(path, map_location=device)
        self.load_state_dict(checkpoint['state_dict'])
        self.knowledge_path = path
        print(f"Knowledge loaded from {path}")
    
    def _get_config(self) -> Dict:
        """Obtiene configuración específica del modelo"""
        return {}

# =============================================================================
# Componentes Meta-Cognitivos
# =============================================================================
class PositionalEncoding2D(nn.Module):
    """Codificación posicional 2D para preservar información espacial en imágenes"""
    def __init__(self, d_model: int, height: int, width: int, dropout: float = 0.1):
        """
        Args:
            d_model: Dimensión del modelo
            height: Alto de la cuadrícula de parches
            width: Ancho de la cuadrícula de parches
            dropout: Probabilidad de dropout
        """
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        # Codificación para dimensiones de altura
        pe_h = torch.zeros(height, d_model)
        position_h = torch.arange(0, height, dtype=torch.float).unsqueeze(1)
        div_term_h = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe_h[:, 0::2] = torch.sin(position_h * div_term_h)
        pe_h[:, 1::2] = torch.cos(position_h * div_term_h)
        
        # Codificación para dimensiones de ancho
        pe_w = torch.zeros(width, d_model)
        position_w = torch.arange(0, width, dtype=torch.float).unsqueeze(1)
        div_term_w = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe_w[:, 0::2] = torch.sin(position_w * div_term_w)
        pe_w[:, 1::2] = torch.cos(position_w * div_term_w)
        
        self.register_buffer('pe_h', pe_h.unsqueeze(1).unsqueeze(0))  # [1, height, 1, d_model]
        self.register_buffer('pe_w', pe_w.unsqueeze(0).unsqueeze(0))  # [1, 1, width, d_model]
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Aplica codificación posicional 2D
        
        Args:
            x: Tensor de entrada [batch, channels, height, width]
        
        Returns:
            Tensor con codificación posicional añadida
        """
        x = x + self.pe_h + self.pe_w
        return self.dropout(x)

class StrategyReasoner(KnowledgePersistentModule):
    """Sistema de toma de decisiones estratégicas basado en contexto"""
    def __init__(self, model_dim: int, num_strategies: int = 8, context_size: int = 3): 
        """
        Args:
            model_dim: Dimensión de los embeddings
            num_strategies: Número de estrategias disponibles
            context_size: Tamaño de la memoria histórica
        """
        super().__init__()
        self.utility_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, num_strategies)
        )
        self.strategy_embeddings = nn.Parameter(torch.randn(num_strategies, model_dim))
        self.context_size = context_size
        
    def forward(self, context: torch.Tensor, problem_embed: torch.Tensor, 
                history: deque) -> torch.Tensor:
        """
        Selecciona una estrategia basada en contexto y historial
        
        Args:
            context: Contexto actual [B, D]
            problem_embed: Representación del problema [B, D]
            history: Historial de contextos anteriores
            
        Returns:
            Vector de estrategia seleccionada [B, D]
        """
        # Combinar contexto histórico
        if len(history) > 0:
            hist_context = torch.stack(list(history)[-self.context_size:]).mean(dim=0)
        else:
            hist_context = torch.zeros_like(context)
        
        # Entrada: [contexto actual, problema, contexto histórico]
        decision_input = torch.cat([context, problem_embed, hist_context], dim=-1)
        utility = self.utility_predictor(decision_input)
        
        # Selección con exploración controlada
        strategy_probs = F.softmax(utility + 0.3 * torch.randn_like(utility), dim=-1)
        strategy_idx = torch.multinomial(strategy_probs, 1)
        return self.strategy_embeddings[strategy_idx].squeeze(1)
    
    def _get_config(self) -> Dict:
        return {
            'model_dim': self.utility_predictor[0].in_features // 3,
            'num_strategies': self.strategy_embeddings.size(0),
            'context_size': self.context_size
        }

class SolutionMonitor(KnowledgePersistentModule):
    """Sistema de autoevaluación crítica de soluciones"""
    def __init__(self, model_dim: int):
        """
        Args:
            model_dim: Dimensión de los embeddings
        """
        super().__init__()
        self.quality_predictor = nn.Sequential(
            nn.Linear(model_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, 4)  # Coherencia, completitud, precisión, eficiencia
        )

        
    def forward(self, solution: torch.Tensor, input_tokens: torch.Tensor, 
                strategy_vector: torch.Tensor) -> Dict:
        """
        Evalúa la calidad de una solución
        
        Args:
            solution: Tensor de solución [B, N, D]
            input_tokens: Tensor de entrada [B, N, D]
            strategy_vector: Vector de estrategia [B, D]
            
        Returns:
            Dict con evaluación, confianza y flag de corrección
        """
        # Preparar entradas (promedio sobre secuencia)
        solution_context = solution.mean(dim=1)  # [B, D]
        input_context = input_tokens.mean(dim=1)  # [B, D]
        
        # Evaluación multidimensional
        assessment = self.quality_predictor(
            torch.cat([solution_context, input_context, strategy_vector], dim=-1)
        )
        
        # Calcular confianza (inverso de la entropía)
        probs = F.softmax(assessment, dim=-1)
        entropy = -(probs * torch.log(probs + 1e-9)).sum(dim=-1)
        confidence = 1.0 - entropy / torch.log(torch.tensor(4.0))  # Normalizado
        
        return {
            'assessment': assessment,
            'confidence': confidence,
            'needs_correction': torch.any(probs < 0.6, dim=-1)
        }

    def _get_config(self) -> Dict:
        return {
            'model_dim': self.quality_predictor[0].in_features // 3
        }

class ResidualAdapter(KnowledgePersistentModule):
    """Módulo de adaptación paramétrica condicionado por estrategia"""
    def __init__(self, dim: int, bottleneck: int = 32, alpha: float = 0.2):
        """
        Args:
            dim: Dimensión de entrada/salida
            bottleneck: Dimensión intermedia
            alpha: Factor de mezcla para el residuo
        """
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, bottleneck),
            nn.ReLU(),
            nn.Linear(bottleneck, dim)
        )
        self.strategy_proj = nn.Linear(dim, bottleneck)
        self.alpha = alpha

    def forward(self, x: torch.Tensor, prior: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Aplica adaptación paramétrica
        
        Args:
            x: Tensor de entrada [B, N, D]
            prior: Vector de estrategia [B, D]
            
        Returns:
            Tensor adaptado [B, N, D]
        """
        out = self.net(x)
        if prior is not None:
            # Proyectar estrategia y combinar
            strategy_feat = self.strategy_proj(prior).unsqueeze(1)
            out = out + strategy_feat
        return x + self.alpha * out
    
    def _get_config(self) -> Dict:
        return {
            'dim': self.net[0].in_features,
            'bottleneck': self.net[0].out_features,
            'alpha': self.alpha
        }

class GeometricClustering(KnowledgePersistentModule):
    """Módulo de agrupamiento geométrico para análisis espacial"""
    def __init__(self, token_dim: int, num_clusters: int = 8):
        """
        Args:
            token_dim: Dimensión de los tokens
            num_clusters: Número de clusters
        """
        super().__init__()
        self.centers = nn.Parameter(torch.randn(num_clusters, token_dim) * 0.1)
        self.spatial_attn = nn.MultiheadAttention(token_dim, num_heads=4, batch_first=True)
        
    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        """
        Calcula asignación suave a clusters
        
        Args:
            tokens: Tensor de entrada [B, N, D]
            
        Returns:
            Asignación a clusters [B, N, K]
        """
        attn_out, _ = self.spatial_attn(tokens, tokens, tokens)
        dists = torch.cdist(attn_out, self.centers.unsqueeze(0).expand(tokens.size(0), -1, -1))
        return F.softmax(-dists, dim=-1)

    def _get_config(self) -> Dict:
        return {
            'token_dim': self.centers.size(1),
            'num_clusters': self.centers.size(0)
        }

# =============================================================================
# Modelo Principal Mejorado - EnhancedMetaARCTransformer
# =============================================================================
'''
class EnhancedMetaARCTransformerBW(nn.Module):
    def __init__(self, token_dim: int = 1,  # Ahora solo 1 canal (binario)
                 model_dim: int = 96,       # Reducir dimensión
                 nhead: int = 6,            # Reducir cabezas
                 nhid: int = 192,           # Reducir capa FFN
                 nlayers: int = 3,          # Reducir capas
                 num_strategies: int = 6,   # Reducir estrategias
                 num_clusters: int = 4,     # Reducir clusters
                 img_size: int = 30, 
                 patch_size: int = 5):
        super().__init__()
        # ... (resto de inicialización)
        
        # CABEZA DE SALIDA SIMPLIFICADA (BINARIA)
        self.pixel_head = nn.Sequential(
            nn.Linear(model_dim, 1),  # Solo 1 salida para clasificación binaria
            nn.Sigmoid()               # Función de activación para binario
        )
    
    def forward(self, tokens: torch.Tensor, max_steps: Optional[int] = None) -> Dict:
        # ... (procesamiento anterior)
        
        # Generar salida binaria
        pixel_output = self.pixel_head(final_output)
        
        return {
            'pixel_output': pixel_output,  # Ahora es probabilidad [0,1]
            # ... (otros campos)
        }
'''
class EnhancedMetaARCTransformer(KnowledgePersistentModule):
    """Modelo ARC mejorado con capacidades meta-cognitivas"""
    
    def __init__(self, token_dim: int, model_dim: int, nhead: int, nhid: int, 
                 nlayers: int, num_strategies: int = 8, num_clusters: int = 8,
                 img_size: int = 30, patch_size: int = 5):
        """
        Args:
            token_dim: Dimensión de los tokens de entrada
            model_dim: Dimensión interna del modelo
            nhead: Número de cabezas de atención
            nhid: Dimensión de las capas feed-forward
            nlayers: Número de capas Transformer
            num_strategies: Número de estrategias disponibles
            num_clusters: Número de clusters para agrupamiento geométrico
            img_size: Tamaño de las imágenes de entrada
            patch_size: Tamaño de los parches para procesamiento 2D
        """
        super().__init__()
        self.token_dim = token_dim
        self.model_dim = model_dim
        self.img_size = img_size
        self.patch_size = patch_size
        self.grid_size = img_size // patch_size
        
        # =====================================================================
        # 1. Componentes de Procesamiento de Entrada
        # =====================================================================
        # Procesamiento por parches para imágenes 2D
        self.patch_embedding = nn.Conv2d(1, model_dim, kernel_size=patch_size, stride=patch_size)
        self.pos_encoder_2d = PositionalEncoding2D(model_dim, self.grid_size, self.grid_size)
        
        # =====================================================================
        # 2. Sistema Meta-Cognitivo
        # =====================================================================
        # Razonamiento estratégico
        self.strategy_reasoner = StrategyReasoner(model_dim, num_strategies)
        
        # Adaptadores residuales por capa
        self.adapters = nn.ModuleList([
            ResidualAdapter(model_dim) for _ in range(nlayers)
        ])
        
        # Autoevaluación y monitoreo
        self.solution_monitor = SolutionMonitor(model_dim)
        
        # Control de ejecución adaptativa
        self.control_net = nn.GRUCell(model_dim, model_dim)
        
        # Memoria contextual (historial de estrategias)
        self.context_memory = deque(maxlen=5)
        
        # =====================================================================
        # 3. Núcleo de Transformación
        # =====================================================================
        encoder_layer = TransformerEncoderLayer(
            d_model=model_dim, 
            nhead=nhead, 
            dim_feedforward=nhid,
            batch_first=True,
            dropout=0.1
        )
        self.transformer = TransformerEncoder(encoder_layer, num_layers=nlayers)
        
        # =====================================================================
        # 4. Componentes de Salida
        # =====================================================================
        self.pixel_head = nn.Linear(model_dim, 11)  # 11 clases (0-10)
        self.geometric_head = GeometricClustering(model_dim, num_clusters)
        
        # =====================================================================
        # 5. Parámetros Operativos
        # =====================================================================
        self.max_steps = 5  # Máximo de pasos de razonamiento
        self.confidence_threshold = 0.85  # Umbral para terminación temprana
        self.correction_factors = nn.Parameter(torch.tensor([0.3, 0.2]), requires_grad=False)

        # =====================================================================
        # Técnicas Anti-Overfitting
        # =====================================================================
        # 1. Dropout más agresivo
        self.input_dropout = nn.Dropout2d(dropout)
        
        # 2. Normalización por capas
        self.layer_norm = nn.LayerNorm(model_dim)
        
        # 3. Regularización estocástica de profundidad
        self.layer_drop_probs = torch.linspace(0, 0.3, nlayers)
        
        # 4. Pérdida de consistencia
        self.consistency_loss_weight = 0.1

    def forward(self, tokens: torch.Tensor, max_steps: Optional[int] = None) -> Dict:
        """
        Procesamiento completo con capacidades meta-cognitivas
        
        Args:
            tokens: Tensor de entrada [B, C, H, W]
            max_steps: Máximo de pasos de razonamiento (opcional)
            
        Returns:
            Dict con resultados y metadatos del proceso
        """
        # Aplicar dropout de entrada
        tokens = self.input_dropout(tokens)

        B = tokens.size(0)
        max_steps = max_steps or self.max_steps
        
        # =====================================================================
        # FASE 1: PROCESAMIENTO INICIAL
        # =====================================================================
        # Convertir a representación 2D por parches
        x = self.patch_embedding(tokens)  # [B, D, grid_h, grid_w]
        x = x.permute(0, 2, 3, 1)  # [B, grid_h, grid_w, D]
        x = x.reshape(B, -1, self.model_dim)  # [B, seq_len, D]
        x = self.pos_encoder_2d(x)  # Aplicar codificación posicional 2D
        
        # Representación inicial del problema
        initial_context = x.mean(dim=1)  # [B, D]
        
        # =====================================================================
        # FASE 2: RAZONAMIENTO ESTRATÉGICO
        # =====================================================================
        strategy_vector = self.strategy_reasoner(
            initial_context, 
            initial_context, 
            self.context_memory
        )
        
        # Actualizar memoria contextual
        self.update_context_memory(initial_context)
        
        # =====================================================================
        # FASE 3: EJECUCIÓN ADAPTATIVA
        # =====================================================================
        state = initial_context.clone()
        solution_trajectory = []
        confidence = torch.zeros(B, device=tokens.device)
        needs_correction = torch.ones(B, dtype=torch.bool, device=tokens.device)
        correction_applied = torch.zeros(B, dtype=torch.bool, device=tokens.device)
        
        for step in range(max_steps):
            
            # Regularización estocástica de profundidad
            if self.training and torch.rand(1) < self.layer_drop_probs[step]:
                continue
 
            # Transformación principal con normalización
            x = self.transformer(x)
            x = self.layer_norm(x)
            
            # Aplicar adaptadores condicionados por estrategia
            for adapter in self.adapters:
                x = adapter(x, prior=strategy_vector)
            
            # =================================================================
            # FASE 4: AUTOVALUACIÓN CRÍTICA
            # =================================================================
            assessment = self.solution_monitor(x, tokens, strategy_vector)
            confidence = assessment['confidence']
            needs_correction = assessment['needs_correction']
            
            # =================================================================
            # FASE 5: ADAPTACIÓN EN TIEMPO REAL
            # =================================================================
            if needs_correction.any():
                correction_applied[needs_correction] = True
                
                # Corrección de coherencia
                if assessment['assessment'][:, 0].min() < 0.6:
                    global_feat = x.mean(dim=1, keepdim=True)
                    x = x + self.correction_factors[0] * global_feat
                
                # Corrección de completitud
                if assessment['assessment'][:, 1].min() < 0.6:
                    sparse_feat = self.compute_sparse_features(x)
                    x = x + self.correction_factors[1] * sparse_feat
            
            # Actualizar estado de control
            state = self.control_net(x.mean(dim=1), state)
            solution_trajectory.append(x)
            
            # Terminación temprana si alta confianza
            if (confidence > self.confidence_threshold).all():
                break
        
        # =====================================================================
        # FASE 6: GENERACIÓN DE SALIDA
        # =====================================================================
        # Usar el último estado de la trayectoria
        final_output = solution_trajectory[-1]
        
        # Cabezas de salida
        pixel_logits = self.pixel_head(final_output)
        cluster_assign = self.geometric_head(final_output)
        
        # Reconstruir a formato 2D
        pixel_logits = self.reconstruct_2d(pixel_logits)
        
        outputs = {
            'pixel_logits': pixel_logits,
            'cluster_assign': cluster_assign,
            'strategy_vector': strategy_vector,
            'trajectory': solution_trajectory,
            'steps': len(solution_trajectory),
            'confidence': confidence,
            'needed_correction': needs_correction,
            'correction_applied': correction_applied,
            'consistency_loss': 0
        }

        # =====================================================================
        # Pérdida de Consistencia (Anti-Overfitting)
        # =====================================================================
        if self.training:
            # Calcular consistencia entre pasos
            consistency_loss = 0
            for i in range(1, len(solution_trajectory)):
                diff = solution_trajectory[i] - solution_trajectory[i-1]
                consistency_loss += torch.mean(torch.abs(diff))
            
            # Agregar a las salidas para uso en la pérdida
            outputs['consistency_loss'] = consistency_loss * self.consistency_loss_weight
        
        return outputs

        
    
    def compute_sparse_features(self, x: torch.Tensor) -> torch.Tensor:
        """Calcula características para corrección de completitud"""
        # Atención a componentes infra-representados
        quantile_val = x.quantile(0.3, dim=1, keepdim=True)
        sparse_mask = (x < quantile_val).float()
        return x * sparse_mask
    
    def reconstruct_2d(self, x: torch.Tensor) -> torch.Tensor:
        """Reconstruye la salida a formato 2D"""
        B, seq_len, C = x.shape
        x = x.view(B, self.grid_size, self.grid_size, C)
        x = x.permute(0, 3, 1, 2)  # [B, C, grid_h, grid_w]
        x = F.interpolate(x, size=(self.img_size, self.img_size), mode='nearest')
        return x
    
    def update_context_memory(self, context: torch.Tensor):
        """Actualiza la memoria contextual con contexto nuevo"""
        self.context_memory.append(context.detach().clone())
    
    def reset_context_memory(self):
        """Reinicia la memoria contextual entre tareas"""
        self.context_memory.clear()
    
    def save_knowledge(self, base_path: str):
        """Guarda conocimiento de todos los componentes"""
        # Crear directorio si no existe
        os.makedirs(base_path, exist_ok=True)
        
        # Guardar componentes principales
        self.strategy_reasoner.save_knowledge(os.path.join(base_path, "strategy_reasoner.pt"))
        self.solution_monitor.save_knowledge(os.path.join(base_path, "solution_monitor.pt"))
        self.geometric_head.save_knowledge(os.path.join(base_path, "geometric_head.pt"))
        
        # Guardar adaptadores
        for i, adapter in enumerate(self.adapters):
            adapter.save_knowledge(os.path.join(base_path, f"residual_adapter_{i}.pt"))
        
        # Guardar el modelo principal
        main_path = os.path.join(base_path, "main_model.pt")
        super().save_knowledge(main_path)
    
    def load_knowledge(self, base_path: str, device: torch.device):
        """Carga conocimiento de todos los componentes"""
        # Cargar componentes principales
        self.strategy_reasoner.load_knowledge(os.path.join(base_path, "strategy_reasoner.pt"), device)
        self.solution_monitor.load_knowledge(os.path.join(base_path, "solution_monitor.pt"), device)
        self.geometric_head.load_knowledge(os.path.join(base_path, "geometric_head.pt"), device)
        
        # Cargar adaptadores
        for i, adapter in enumerate(self.adapters):
            adapter_path = os.path.join(base_path, f"residual_adapter_{i}.pt")
            if os.path.exists(adapter_path):
                adapter.load_knowledge(adapter_path, device)
        
        # Cargar modelo principal
        main_path = os.path.join(base_path, "main_model.pt")
        super().load_knowledge(main_path, device)

# =============================================================================
# Dataset y Pipeline de Entrenamiento
# =============================================================================
'''
class ARCTrainBW(Dataset):
    def __init__(self, root: str, imgsz: int = 30):
        # ... (carga inicial)
        
        # Conversión binaria directa
        self.train_x_batch = [ (x > BINARY_THRESHOLD).astype(np.float32) for x in self.train_x_batch ]
        self.train_y_batch = [ (y > BINARY_THRESHOLD).astype(np.float32) for y in self.train_y_batch ]
        self.val_x_batch = (self.val_x_batch > BINARY_THRESHOLD).astype(np.float32)
        self.val_y_batch = (self.val_y_batch > BINARY_THRESHOLD).astype(np.float32)

    def __getitem__(self, index: int) -> Tuple[torch.Tensor, torch.Tensor]:
        x = torch.tensor(self.train_x_batch[index], dtype=torch.float32)
        y = torch.tensor(self.train_y_batch[index], dtype=torch.float32)  # Ahora float para BCE
        return x.unsqueeze(1), y.reshape(-1)  # Mantener dimensión de canal
'''
class ARCTrain(Dataset):
    """Dataset para entrenamiento con tareas ARC"""
    def __init__(self, root: str, imgsz: int = 30):
        super().__init__()
        self.out_rows, self.out_cols = imgsz, imgsz
        
        # Cargar y preparar datos
        task_paths = glob(f'{root}/training/*.json')
        self.train_x_batch, self.train_y_batch, self.val_x_batch, self.val_y_batch = (
            create_batch(task_paths, self.out_rows, self.out_cols)
        )
        
        # Combinar con datos de evaluación
        eval_task_paths = glob(f'{root}/evaluation/*.json')
        test_task_ids = [os.path.basename(p) for p in glob(f'{root}/test/*.json')]
        eval_task_paths = [p for p in eval_task_paths if os.path.basename(p) not in test_task_ids]
        
        eval_train_x, eval_train_y, eval_val_x, eval_val_y = create_batch(
            eval_task_paths, self.out_rows, self.out_cols)
        
        # Combinar conjuntos
        self.train_x_batch += eval_train_x
        self.train_y_batch += eval_train_y
        self.val_x_batch = np.vstack(self.val_x_batch + eval_val_x)
        self.val_y_batch = np.vstack(self.val_y_batch + eval_val_y)
        
        # Convertir a tensores
        self.val_x_batch = torch.tensor(self.val_x_batch, dtype=torch.float32)
        self.val_y_batch = torch.tensor(self.val_y_batch, dtype=torch.long)
        
        print(f'Loaded {len(self.train_x_batch)} training tasks')
        print(f'Validation set size: {len(self.val_x_batch)}')

    def __getitem__(self, index: int) -> Tuple[torch.Tensor, torch.Tensor]:
        x = torch.tensor(self.train_x_batch[index], dtype=torch.float32)
        y = torch.tensor(self.train_y_batch[index], dtype=torch.long)
        return x.unsqueeze(1), y.reshape(-1)  # Añadir dimensión de canal

    def __len__(self) -> int:
        return len(self.train_x_batch)

# =============================================================================
# Sistema de Entrenamiento 
# =============================================================================
class ARCTrainer:
    def __init__(self, model: nn.Module, device: torch.device, 
                 base_path: str = "arc_knowledge"):
        self.model = model
        self.device = device
        self.base_path = base_path
        self.best_val_acc = 0.0
        self.early_stopping_counter = 0
        
        # Configuración de optimizador para fine-tuning
        self.finetune_mode = False
        self.original_lr = 1e-3
        self.finetune_lr = 1e-5
        
        # Crear directorio para conocimiento
        os.makedirs(base_path, exist_ok=True)
    
    def configure_optimizer(self, finetune: bool = False):
        """Configura optimizador considerando modo de fine-tuning"""
        self.finetune_mode = finetune
        
        # Grupos de parámetros con diferentes tasas de aprendizaje
        strategy_params = list(self.model.strategy_reasoner.parameters())
        adapter_params = []
        for adapter in self.model.adapters:
            adapter_params += list(adapter.parameters())
        
        main_params = (
            list(self.model.patch_embedding.parameters()) +
            list(self.model.transformer.parameters()) +
            list(self.model.pixel_head.parameters()) +
            list(self.model.geometric_head.parameters()) +
            list(self.model.solution_monitor.parameters())
        )
        
        # Tasas de aprendizaje diferenciadas
        lr = self.finetune_lr if finetune else self.original_lr
        param_groups = [
            {'params': strategy_params, 'lr': lr * 0.1},
            {'params': adapter_params, 'lr': lr},
            {'params': main_params, 'lr': lr}
        ]
        
        return torch.optim.AdamW(param_groups, weight_decay=1e-4)
    
    def train(self, arc_dataset: ARCTrain, epochs: int, patience: int = 10, finetune: bool = False):
        """Entrenamiento con prevención de overfitting"""
        optimizer = self.configure_optimizer(finetune)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='max', factor=0.5, patience=5, verbose=True
        )
        
        for epoch in range(1, epochs + 1):
            # Reiniciar memoria contextual al inicio de cada época
            self.model.reset_context_memory()
            
            # Entrenar una época
            train_metrics = train_epoch(
                self.model, arc_dataset, optimizer, self.device, epoch
            )
            
            # Validación
            val_acc, val_conf = validation(
                self.model, 
                np.stack(arc_dataset.val_x_batch), 
                np.stack(arc_dataset.val_y_batch),
                self.device
            )
            
            # Actualizar scheduler
            scheduler.step(val_acc)
            
            # Guardar mejor modelo
            if val_acc > self.best_val_acc:
                self.best_val_acc = val_acc
                self.early_stopping_counter = 0
                self.model.save_knowledge(
                    os.path.join(self.base_path, f"best_epoch_{epoch}")
                )
            else:
                self.early_stopping_counter += 1
            
            # Early stopping
            if self.early_stopping_counter >= patience:
                print(f"Early stopping at epoch {epoch}")
                break
    
    def finetune(self, finetune_dataset: ARCTrain, epochs: int, 
                 patience: int = 5, learning_rate: float = 1e-5):
        """Fine-tuning especializado en un conjunto de datos específico"""
        # Congelar componentes principales
        for param in self.model.patch_embedding.parameters():
            param.requires_grad = False
        for param in self.model.transformer.parameters():
            param.requires_grad = False
        
        # Mantener adaptadores y componentes estratégicos entrenables
        for adapter in self.model.adapters:
            for param in adapter.parameters():
                param.requires_grad = True
        for param in self.model.strategy_reasoner.parameters():
            param.requires_grad = True
        for param in self.model.solution_monitor.parameters():
            param.requires_grad = True
        
        # Configurar optimizador para fine-tuning
        self.finetune_lr = learning_rate
        self.train(finetune_dataset, epochs, patience, finetune=True)
    
    def load_knowledge(self, path: str = None):
        """Carga conocimiento existente"""
        load_path = path or os.path.join(self.base_path, "best_model")
        self.model.load_knowledge(load_path, self.device)
        print("Knowledge loaded successfully")

# =============================================================================
# Funciones de Evaluación y Entrenamiento
# =============================================================================
@torch.no_grad()
def validationO(model: nn.Module, arc_dataset: ARCTrain, imgsz: int, 
               num_class: int, device: torch.device) -> Tuple[float, float]:
    """Evalúa el modelo en el conjunto de validación"""
    model.eval()
    outputs = model(arc_dataset.val_x_batch.to(device))
    
    # Obtener logits de píxeles
    pixel_logits = outputs['pixel_logits']
    
    # Calcular predicciones
    preds = pixel_logits.argmax(1)  # [B, H, W]
    
    # Aplanar para comparación
    preds_flat = preds.reshape(-1)
    true_flat = arc_dataset.val_y_batch.reshape(-1).to(device)
    
    # Filtrar padding (valor 10)
    non_pad = (true_flat != 10)
    acc = (preds_flat[non_pad] == true_flat[non_pad]).float().mean().item()
    
    # Calcular confianza promedio
    confidence = outputs.get('confidence', torch.tensor(0.0)).mean().item()
    
    return acc, confidence

'''
@torch.no_grad()
def validationBW(model: nn.Module, val_x: np.ndarray, val_y: np.ndarray, 
               imgsz: int, device: torch.device) -> Tuple[float, float]:
    
    for i in range(0, len(val_x), batch_size):
        batch_x = torch.tensor(val_x[i:i+batch_size], dtype=torch.float32).unsqueeze(1).to(device)
        batch_y = torch.tensor(val_y[i:i+batch_size], dtype=torch.float32).to(device)
        
        outputs = model(batch_x)
        pixel_output = outputs['pixel_output']
        
        # Calcular predicciones binarias
        preds = (pixel_output > 0.5).float().reshape(batch_x.size(0), -1)
        
        # Calcular precisión binaria
        acc = (preds == batch_y).float().mean().item()
'''
@torch.no_grad()
def validation(model: nn.Module, val_x: np.ndarray, val_y: np.ndarray, 
               imgsz: int, num_class: int, device: torch.device) -> Tuple[float, float]:
    """Validación con manejo de memoria contextual y batches"""
    model.eval()
    total_correct = 0
    total_pixels = 0
    total_confidence = 0.0
    batch_size = 32  # Procesar en batches para ahorrar memoria

    for i in range(0, len(val_x), batch_size):
        batch_x = torch.tensor(val_x[i:i+batch_size], dtype=torch.float32).unsqueeze(1).to(device)
        batch_y = torch.tensor(val_y[i:i+batch_size], dtype=torch.long).to(device)
        
        # Reiniciar memoria para cada batch
        model.reset_context_memory()
        
        outputs = model(batch_x)
        pixel_logits = outputs['pixel_logits']
        preds = pixel_logits.argmax(1).reshape(batch_x.size(0), -1)
        
        # Calcular precisión
        non_pad = (batch_y != PAD_VALUE)
        correct = (preds[non_pad] == batch_y[non_pad]).sum().item()
        total_correct += correct
        total_pixels += non_pad.sum().item()
        total_confidence += outputs.get('confidence', torch.tensor(0.0)).mean().item()
    
    accuracy = total_correct / total_pixels
    avg_confidence = total_confidence / (len(val_x) / batch_size)
    return accuracy, avg_confidence

'''
def train_epochBW(model: nn.Module, arc_dataset: ARCTrain, optimizer: torch.optim.Optimizer,
                device: torch.device, epoch: int) -> Dict[str, float]:  # Eliminado num_class
    
    for i, task_idx in enumerate(task_ids):
        x, y = arc_dataset[task_idx]
        x, y = x.to(device), y.to(device)
        
        outputs = model(x)
        pixel_output = outputs['pixel_output']
        
        # PÉRDIDA BINARIA (BCE)
        loss = F.binary_cross_entropy(
            pixel_output.view(-1), 
            y.view(-1),
            reduction='mean'
        )
        
        # ... (resto del entrenamiento)
        
        # Calcular precisión binaria
        preds = (pixel_output > 0.5).float()
        acc = (preds == y).float().mean().item()

Optimizaciones Adicionales
Para mayor eficiencia, puedes añadir:

python
# En la función de entrenamiento
def train_epochBW(...):
    # Usar autocast para mixed precision
    with torch.cuda.amp.autocast():
        outputs = model(x)
        loss = F.binary_cross_entropy(...)
    
    # Backprop con escalado
    scaler.scale(loss).backward()
    scaler.step(optimizer)
    scaler.update()

# En la inicialización
scaler = torch.cuda.amp.GradScaler()  # Para mixed precision

# Reducción de resolución (opcional)
IMG_SIZE = 20  # En lugar de 30
'''

def train_epoch(model: nn.Module, arc_dataset: ARCTrain, optimizer: torch.optim.Optimizer,
                device: torch.device, epoch: int, num_class: int) -> Dict[str, float]:
    """Entrena el modelo durante una época completa"""
    model.train()
    total_loss = 0.0
    total_acc = 0.0
    total_corrections = 0.0
    total_steps = 0
    batch_count = 0
    
    # Barajar tareas
    task_ids = np.arange(len(arc_dataset))
    np.random.shuffle(task_ids)
    
    for i, task_idx in enumerate(task_ids):
        # Reiniciar memoria entre tareas
        model.reset_context_memory()
        
        # Obtener datos de la tarea
        x, y = arc_dataset[task_idx]
        x = x.to(device)
        y = y.to(device)
        ## Modificado
        
        outputs = model(x)
        pixel_output = outputs['pixel_output']
        
        # Pérdida principal
        main_loss = F.binary_cross_entropy(
            pixel_output.view(-1), 
            y.view(-1),
            reduction='mean'
        )
        
        # Pérdida de consistencia
        consistency_loss = outputs.get('consistency_loss', torch.tensor(0.0))
        
        # Pérdida total
        total_loss = main_loss + consistency_loss


        '''
        # Forward pass
        outputs = model(x)
        pixel_logits = outputs['pixel_logits']
                
        # Calcular pérdida
        loss = F.cross_entropy(pixel_logits, y)
        
        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # Calcular precisión
        preds = pixel_logits.argmax(1)
        acc = (preds == y).float().mean().item()
        
        # Estadísticas
        total_loss += loss.item()
        '''
        total_acc += acc
        total_corrections += outputs['correction_applied'].float().mean().item()
        total_steps += outputs['steps']
        batch_count += 1
        
        # Reporte periódico
        if i % 10 == 0:
            print(f'Epoch {epoch} | Batch {i}/{len(task_ids)} | '
                  f'Loss: {loss.item():.4f} | Acc: {acc:.4f} | '
                  f'Steps: {outputs["steps"]} | Conf: {outputs["confidence"].mean().item():.4f} | '
                  f'Corr: {outputs["correction_applied"].float().mean().item():.4f}')
    
    return {
        'avg_loss': total_loss / batch_count,
        'avg_acc': total_acc / batch_count,
        'avg_corrections': total_corrections / batch_count,
        'avg_steps': total_steps / batch_count
    }

'''
def mainBW(epochs: int, imgsz: int, data_root: str):  # Eliminado num_class
    # Parámetros reducidos
    token_dim = 1  # Binario
    model_dim = 96
    nhead = 6
    nhid = 192
    nlayers = 3
    num_strategies = 6
    num_clusters = 4
    
    # Crear modelo
    model = EnhancedMetaARCTransformer(
        token_dim=token_dim,
        model_dim=model_dim,
        nhead=nhead,
        nhid=nhid,
        nlayers=nlayers,
        num_strategies=num_strategies,
        num_clusters=num_clusters,
        img_size=imgsz,
        patch_size=5
    ).to(device)
'''
def main(epochs: int, imgsz: int, num_class: int, data_root: str,
         load_knowledge: bool = False, finetune: bool = False):
    
    """Pipeline principal de entrenamiento y evaluación"""
    # Configuración inicial
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    seed_everything(42)
    print(f'Using device: {device}')
    
    # Parámetros del modelo
    token_dim = 1  # Imágenes en escala de grises
    model_dim = 128
    nhead = 8
    nhid = 256
    nlayers = 4
    num_strategies = 8
    num_clusters = 6
    
    # Crear modelo
    model = EnhancedMetaARCTransformer(
        token_dim=token_dim,
        model_dim=model_dim,
        nhead=nhead,
        nhid=nhid,
        nlayers=nlayers,
        num_strategies=num_strategies,
        num_clusters=num_clusters,
        img_size=imgsz,
        patch_size=5
    ).to(device)
    
    # Cargar conocimiento existente si se solicita
    trainer = ARCTrainer(model, device)
    if load_knowledge:
        trainer.load_knowledge()
    
    # Entrenar o hacer fine-tuning
    if finetune:
        trainer.finetune(arc_dataset, epochs=10, learning_rate=1e-5)
    else:
        trainer.train(arc_dataset, epochs)

    # Contar parámetros
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'Model created with {total_params:,} trainable parameters')
    
    # Cargar datos
    arc_dataset = ARCTrain(root=data_root, imgsz=imgsz)
    arc_dataset.val_x_batch = arc_dataset.val_x_batch.to(device)
    arc_dataset.val_y_batch = arc_dataset.val_y_batch.to(device)
    
    # Optimizador
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    
    # Entrenamiento
    best_val_acc = 0.0
    history = {'train_loss': [], 'val_acc': [], 'val_conf': []}
    
    # Crear GradScaler para mixed precision
    scaler = torch.cuda.amp.GradScaler() if torch.cuda.is_available() else None

    # Entrenamiento
    for epoch in range(1, epochs + 1):
        # Fase de entrenamiento
        train_metrics = train_epoch(
            model, 
            arc_dataset, 
            optimizer, 
            device, 
            epoch,  
            num_class
        )
        
        # Fase de validación
        '''
        val_acc, val_conf = validationO(
            model, 
            arc_dataset, 
            imgsz, 
            num_class, 
            device
        )
        '''
        # Validación (MODIFICADO)
        val_acc, val_conf = validation(
            model, 
            np.stack(arc_dataset.val_x_batch), 
            np.stack(arc_dataset.val_y_batch),
            imgsz, num_class, device
        )
    
        
        # Guardar historial
        history['train_loss'].append(train_metrics['avg_loss'])
        history['val_acc'].append(val_acc)
        history['val_conf'].append(val_conf)
        
        # Reporte de época
        print(f'\nEpoch {epoch} Summary:')
        print(f'Train Loss: {train_metrics["avg_loss"]:.4f} | Acc: {train_metrics["avg_acc"]:.4f}')
        print(f'Val Acc: {val_acc:.4f} | Conf: {val_conf:.4f}')
        print(f'Avg Steps: {train_metrics["avg_steps"]:.2f} | Corrections: {train_metrics["avg_corrections"]:.4f}\n')
        
        # Guardar mejor modelo
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), f'best_model_epoch{epoch}_acc{val_acc:.4f}.pth')
            print(f'Saved new best model with accuracy {val_acc:.4f}')
    
    print(f'Training completed. Best validation accuracy: {best_val_acc:.4f}')
    
    # Visualizar resultados
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Train Loss')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.legend()
    
    plt.subplot(1, 2, 2)
    plt.plot(history['val_acc'], label='Validation Accuracy')
    plt.plot(history['val_conf'], label='Validation Confidence')
    plt.title('Validation Metrics')
    plt.xlabel('Epoch')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('training_metrics.png')
    plt.close()

if __name__ == '__main__':
    # Parámetros configurables
    EPOCHS = 50
    IMG_SIZE = 30
    NUM_CLASSES = 11  # 0-10 + padding
    DATA_ROOT = '/content/drive/MyDrive/testMeta'  # Actualizar según ubicación de datos
    
    main(epochs=EPOCHS, imgsz=IMG_SIZE, num_class=NUM_CLASSES, data_root=DATA_ROOT)


